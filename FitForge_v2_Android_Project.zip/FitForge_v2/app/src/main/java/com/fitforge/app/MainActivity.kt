package com.fitforge.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max

private val Bg = Color(0xFF090B0E)
private val Card = Color(0xFF15181D)
private val Accent = Color(0xFFB7F34A)
private val Muted = Color(0xFF98A0AA)
private val Danger = Color(0xFFFF6B6B)

data class Targets(
    val calories: Int,
    val protein: Int,
    val fiber: Int,
    val water: Int,
    val steps: Int = 10000
)
data class Log(
    val calories: Int = 0,
    val protein: Int = 0,
    val fiber: Int = 0,
    val water: Int = 0,
    val steps: Int = 0,
    val burned: Int = 0,
    val weight: Double = 0.0
)
data class Meal(val name: String, val calories: Int, val protein: Int, val fiber: Int)
data class Sport(val name: String, val minutes: Int, val calories: Int)

@Composable
fun Theme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Card, primary = Accent,
            onPrimary = Color.Black, onBackground = Color.White, onSurface = Color.White
        ),
        content = content
    )
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Theme { App() } }
    }
}

@Composable
fun App() {
    var setup by remember { mutableStateOf(true) }
    var targets by remember { mutableStateOf(Targets(2300, 140, 30, 3000)) }
    var log by remember { mutableStateOf(Log()) }
    var meals by remember { mutableStateOf(listOf<Meal>()) }
    var sports by remember { mutableStateOf(listOf<Sport>()) }
    var completed by remember { mutableStateOf(setOf<String>()) }
    var page by remember { mutableStateOf("home") }

    if (setup) {
        Setup { t -> targets = t; setup = false }
        return
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Card) {
                listOf("home" to "Home", "food" to "Food", "workout" to "Workout",
                    "progress" to "Progress", "more" to "More").forEach { (key, label) ->
                    NavigationBarItem(
                        selected = page == key,
                        onClick = { page = key },
                        icon = { Text(label.first().toString(), fontWeight = FontWeight.Bold) },
                        label = { Text(label) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (page) {
                "home" -> Home(targets, log, onWater = { ml -> log = log.copy(water = log.water + ml) })
                "food" -> Food(targets, log, meals) { meal ->
                    meals = meals + meal
                    log = log.copy(
                        calories = log.calories + meal.calories,
                        protein = log.protein + meal.protein,
                        fiber = log.fiber + meal.fiber
                    )
                }
                "workout" -> Workout(completed) { id ->
                    completed = if (id in completed) completed - id else completed + id
                }
                "progress" -> Progress(log, sports)
                else -> More { sport ->
                    sports = sports + sport
                    log = log.copy(burned = log.burned + sport.calories)
                }
            }
        }
    }
}

@Composable
fun Setup(onDone: (Targets) -> Unit) {
    var age by remember { mutableStateOf("") }
    var height by remember { mutableStateOf("") }
    var weight by remember { mutableStateOf("") }
    var activity by remember { mutableStateOf("Moderate") }
    var goal by remember { mutableStateOf("Lose") }

    Column(Modifier.fillMaxSize().background(Bg).padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("FITFORGE", color = Accent, fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(Modifier.height(18.dp))
        Text("Build your stronger self.", fontSize = 34.sp, fontWeight = FontWeight.Black)
        Text("“Consistency beats motivation.”", color = Accent, fontSize = 17.sp)
        Spacer(Modifier.height(22.dp))
        Field("Age", age) { age = it.filter(Char::isDigit) }
        Field("Height (cm)", height) { height = it.filter(Char::isDigit) }
        Field("Weight (kg)", weight) { weight = it.filter { c -> c.isDigit() || c == '.' } }
        Text("Activity level", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Low", "Moderate", "High").forEach {
                FilterChip(activity == it, { activity = it }, label = { Text(it) })
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Goal", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Lose", "Maintain", "Gain").forEach {
                FilterChip(goal == it, { goal = it }, label = { Text(it) })
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                val w = weight.toDoubleOrNull() ?: 70.0
                val h = height.toDoubleOrNull() ?: 170.0
                val a = age.toDoubleOrNull() ?: 25.0
                val bmr = 10*w + 6.25*h - 5*a + 5
                val factor = when(activity) { "Low" -> 1.25; "High" -> 1.725; else -> 1.5 }
                val maintenance = bmr * factor
                val calories = when(goal) {
                    "Lose" -> max(1500.0, maintenance - 350).toInt()
                    "Gain" -> (maintenance + 250).toInt()
                    else -> maintenance.toInt()
                }
                val protein = max(60, (w * 1.8).toInt())
                val fiber = max(25, (calories / 1000.0 * 14).toInt())
                val water = max(2000, (w * 35).toInt())
                onDone(Targets(calories, protein, fiber, water))
            },
            Modifier.fillMaxWidth()
        ) { Text("CREATE MY PLAN") }
        Spacer(Modifier.height(8.dp))
        Text("Targets are estimates for planning, not medical advice.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(bottom = 7.dp), singleLine = true)
}

@Composable
fun Home(t: Targets, l: Log, onWater: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("TODAY", color = Accent, fontWeight = FontWeight.Black)
            Text("Keep going. 💪", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("One good choice at a time.", color = Muted)
            Spacer(Modifier.height(16.dp))
            Metric("Calories", l.calories, t.calories, "kcal")
            Metric("Protein", l.protein, t.protein, "g")
            Metric("Fiber", l.fiber, t.fiber, "g")
            Metric("Water", l.water, t.water, "ml")
            Metric("Steps", l.steps, t.steps, "")
            CardBlock {
                Text("Quick water", fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(250, 500, 750, 1000).forEach {
                        OutlinedButton({ onWater(it) }, Modifier.weight(1f)) { Text("${it}ml") }
                    }
                }
            }
            CardBlock {
                Text("🔥 Active calories", fontWeight = FontWeight.Bold)
                Text("${l.burned} kcal", fontSize = 30.sp, fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
fun Metric(name: String, current: Int, target: Int, unit: String) {
    val p = (current.toFloat() / target.coerceAtLeast(1)).coerceIn(0f, 1f)
    CardBlock {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name, fontWeight = FontWeight.Bold)
            Text("${max(0, target-current)} $unit left", color = Accent)
        }
        Spacer(Modifier.height(7.dp))
        LinearProgressIndicator({ p }, Modifier.fillMaxWidth())
        Text("$current / $target $unit", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(colors = CardDefaults.cardColors(Card), shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().padding(bottom = 9.dp)) {
        Column(Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun Food(t: Targets, l: Log, meals: List<Meal>, add: (Meal) -> Unit) {
    var name by remember { mutableStateOf("") }
    var c by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("Nutrition", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("Log what you eat. Your dashboard updates instantly.", color = Muted)
            Spacer(Modifier.height(12.dp))
            Field("Meal / food", name) { name = it }
            Field("Calories", c) { c = it.filter(Char::isDigit) }
            Field("Protein (g)", p) { p = it.filter(Char::isDigit) }
            Field("Fiber (g)", f) { f = it.filter(Char::isDigit) }
            Button({
                if (name.isNotBlank()) {
                    add(Meal(name, c.toIntOrNull() ?: 0, p.toIntOrNull() ?: 0, f.toIntOrNull() ?: 0))
                    name = ""; c = ""; p = ""; f = ""
                }
            }, Modifier.fillMaxWidth()) { Text("ADD MEAL") }
            Spacer(Modifier.height(14.dp))
            Text("Today's meals", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        items(meals.reversed()) { m ->
            CardBlock {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(m.name, fontWeight = FontWeight.Bold)
                    Text("${m.calories} kcal", color = Accent)
                }
                Text("${m.protein}g protein • ${m.fiber}g fiber", color = Muted)
            }
        }
    }
}

@Composable
fun Workout(done: Set<String>, toggle: (String) -> Unit) {
    val plan = mapOf(
        "MON" to listOf("Bench Press", "Incline Dumbbell Press", "Cable Fly", "Triceps Pushdown"),
        "TUE" to listOf("Lat Pulldown", "Seated Row", "Dumbbell Curl", "Hammer Curl"),
        "WED" to listOf("Squat", "Leg Press", "Leg Curl", "Calf Raise"),
        "THU" to listOf("REST / MOBILITY"),
        "FRI" to listOf("Overhead Press", "Lateral Raise", "Rear Delt Fly", "Plank"),
        "SAT" to listOf("Full Body / Sport"),
        "SUN" to listOf("REST")
    )
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("Workout", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("5 training days • recovery included", color = Muted)
            Spacer(Modifier.height(10.dp))
        }
        plan.forEach { (day, exercises) ->
            item {
                CardBlock {
                    Text(day, color = Accent, fontWeight = FontWeight.Black)
                    exercises.forEach { ex ->
                        val id = "$day-$ex"
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(id in done, { toggle(id) })
                            Text(ex, fontWeight = if (id in done) FontWeight.Normal else FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Progress(l: Log, sports: List<Sport>) {
    var weight by remember { mutableStateOf(if (l.weight == 0.0) "" else l.weight.toString()) }
    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("Progress", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("Track the changes you can see and measure.", color = Muted)
            Spacer(Modifier.height(12.dp))
            CardBlock {
                Text("🔥 Streak", fontWeight = FontWeight.Bold)
                Text("3 DAYS", fontSize = 32.sp, fontWeight = FontWeight.Black)
                Text("Scheduled rest days don't break your streak.", color = Muted)
            }
            CardBlock {
                Text("⚖️ Daily weight", fontWeight = FontWeight.Bold)
                Field("Weight (kg)", weight) { weight = it }
                Button({}, Modifier.fillMaxWidth()) { Text("SAVE WEIGHT") }
            }
            CardBlock {
                Text("🏆 Badges", fontWeight = FontWeight.Bold)
                Text("🔥 Consistency starter")
                Text("💪 First workout")
                Text("💧 Hydration starter")
                Text("🥇 First week complete")
            }
            CardBlock {
                Text("📸 Progress gallery", fontWeight = FontWeight.Bold)
                Text("Daily photos + weekly videos will appear here.")
                OutlinedButton({}) { Text("ADD PROGRESS PHOTO") }
            }
            CardBlock {
                Text("🏏 Sports sessions", fontWeight = FontWeight.Bold)
                sports.forEach { Text("${it.name} • ${it.minutes} min • ${it.calories} kcal") }
            }
        }
    }
}

@Composable
fun More(addSport: (Sport) -> Unit) {
    var sport by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }
    var calcWeight by remember { mutableStateOf("") }
    var calcProtein by remember { mutableStateOf("") }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp)) {
        item {
            Text("Tools", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(12.dp))
            CardBlock {
                Text("🧮 Protein calculator", fontWeight = FontWeight.Bold)
                Field("Body weight (kg)", calcWeight) { calcWeight = it.filter { c -> c.isDigit() || c == '.' } }
                val result = (calcWeight.toDoubleOrNull()?.times(1.8))?.toInt()
                Text("Suggested planning range: ${result ?: "--"} g/day", color = Accent)
            }
            CardBlock {
                Text("🔥 Quick calorie calculator", fontWeight = FontWeight.Bold)
                Text("Use your profile target on the Home dashboard; meal calories are logged in Nutrition.")
            }
            CardBlock {
                Text("🏏 Sports mode", fontWeight = FontWeight.Bold)
                Field("Sport", sport) { sport = it }
                Field("Minutes", minutes) { minutes = it.filter(Char::isDigit) }
                Button({
                    val m = minutes.toIntOrNull() ?: 0
                    if (sport.isNotBlank() && m > 0) {
                        addSport(Sport(sport, m, (m * 7)))
                        sport = ""; minutes = ""
                    }
                }, Modifier.fillMaxWidth()) { Text("ADD SPORTS SESSION") }
            }
            CardBlock {
                Text("🤖 Daily coach", fontWeight = FontWeight.Bold)
                Text("Coming next: personalized daily check-ins and suggestions.")
            }
            CardBlock {
                Text("🔔 Reminders", fontWeight = FontWeight.Bold)
                Text("Water • workout • weight • progress photo")
            }
        }
    }
}
