package com.fitforge.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.contract.ActivityResultContracts
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.edit
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private val Ink = Color(0xFF080808)
private val Paper = Color(0xFFF7F7F2)
private val White = Color(0xFFFFFFFF)
private val Lime = Color(0xFFB8F52E)
private val Purple = Color(0xFF7850F2)
private val Pink = Color(0xFFFF6F91)
private val Blue = Color(0xFF5B9CF6)
private val Muted = Color(0xFF666666)

private data class Targets(val calories:Int, val protein:Int, val fiber:Int, val water:Int, val steps:Int=10000, val sleep:Float=8f)
private data class Log(var calories:Int=0,var protein:Int=0,var fiber:Int=0,var water:Int=0,var steps:Int=0,var burned:Int=0,var weight:Double=0.0,var sleep:Float=0f)
private data class Meal(val name:String,val calories:Int,val protein:Int,val fiber:Int,val photo:String="")
private data class Sport(val name:String,val minutes:Int,val calories:Int)

private class Store(context: Context) {
    private val p=context.getSharedPreferences("rise_store", Context.MODE_PRIVATE)
    fun setupDone()=p.getBoolean("setup",false)
    fun saveSetup(t:Targets)=p.edit{putBoolean("setup",true).putInt("cal",t.calories).putInt("protein",t.protein).putInt("fiber",t.fiber).putInt("water",t.water).putInt("steps",t.steps).putFloat("sleepTarget",t.sleep)}
    fun targets()=Targets(p.getInt("cal",2300),p.getInt("protein",140),p.getInt("fiber",30),p.getInt("water",3000),p.getInt("steps",10000),p.getFloat("sleepTarget",8f))
    private fun today():String=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    fun log():Log {
        if(p.getString("day","")!=today()) return Log()
        return Log(p.getInt("c",0),p.getInt("p",0),p.getInt("f",0),p.getInt("w",0),p.getInt("s",0),p.getInt("b",0),p.getString("weight","0")!!.toDoubleOrNull()?:0.0,p.getFloat("sleep",0f))
    }
    fun saveLog(l:Log)=p.edit{putString("day",today()).putInt("c",l.calories).putInt("p",l.protein).putInt("f",l.fiber).putInt("w",l.water).putInt("s",l.steps).putInt("b",l.burned).putString("weight",l.weight.toString()).putFloat("sleep",l.sleep)}
    fun meals():List<Meal>{ val a=JSONArray(p.getString("meals","[]")); return (0 until a.length()).map{val o=a.getJSONObject(it);Meal(o.getString("n"),o.getInt("c"),o.getInt("p"),o.getInt("f"),o.optString("photo"))} }
    fun saveMeals(list:List<Meal>){val a=JSONArray();list.forEach{a.put(JSONObject().put("n",it.name).put("c",it.calories).put("p",it.protein).put("f",it.fiber).put("photo",it.photo))};p.edit{putString("meals",a.toString())}}
    fun sports():List<Sport>{val a=JSONArray(p.getString("sports","[]"));return(0 until a.length()).map{val o=a.getJSONObject(it);Sport(o.getString("n"),o.getInt("m"),o.getInt("c"))}}
    fun saveSports(list:List<Sport>){val a=JSONArray();list.forEach{a.put(JSONObject().put("n",it.name).put("m",it.minutes).put("c",it.calories))};p.edit{putString("sports",a.toString())}}
    fun done():Set<String> = p.getStringSet("done",emptySet()) ?: emptySet()
    fun saveDone(s:Set<String>)=p.edit{putStringSet("done",s)}
    fun media():List<String> = p.getStringSet("media",emptySet())?.toList()?:emptyList()
    fun saveMedia(s:Set<String>)=p.edit{putStringSet("media",s)}
}

@Composable private fun RiseTheme(content:@Composable()->Unit){MaterialTheme(colorScheme=lightColorScheme(background=Paper,surface=White,primary=Ink,onPrimary=White,onBackground=Ink,onSurface=Ink)){content()}}

class MainActivity:ComponentActivity(){
    private lateinit var store:Store
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);store=Store(this);setContent{RiseTheme{App(store)}}}
}

@Composable private fun App(store:Store){
    var setup by remember{mutableStateOf(!store.setupDone())}
    var targets by remember{mutableStateOf(store.targets())}
    var log by remember{mutableStateOf(store.log())}
    var meals by remember{mutableStateOf(store.meals())}
    var sports by remember{mutableStateOf(store.sports())}
    var done by remember{mutableStateOf(store.done())}
    var media by remember{mutableStateOf(store.media())}
    var page by remember{mutableStateOf("home")}
    if(setup){Setup{t->targets=t;store.saveSetup(t);setup=false};return}
    fun update(l:Log){log=l;store.saveLog(l)}
    Scaffold(containerColor=Paper,bottomBar={BottomNav(page){page=it}}){pad->Box(Modifier.fillMaxSize().padding(pad)){when(page){"home"->Home(targets,log){ml->update(log.copy(water=log.water+ml))};"food"->Food(log,meals){m->meals=meals+m;store.saveMeals(meals);update(log.copy(calories=log.calories+m.calories,protein=log.protein+m.protein,fiber=log.fiber+m.fiber))};"workout"->Workout(done){id->done=if(id in done)done-id else done+id;store.saveDone(done)};"progress"->Progress(log,media){w->update(log.copy(weight=w))};else->More(log,sports,media,{s->sports=sports+s;store.saveSports(sports);update(log.copy(burned=log.burned+s.calories))},{u->media=media+u;store.saveMedia(media.toSet())},{hours->update(log.copy(sleep=hours))})}}}}
}

@Composable private fun BottomNav(page:String,go:(String)->Unit){NavigationBar(containerColor=Ink){listOf("home" to "⌂\nHOME","food" to "◒\nFOOD","workout" to "✦\nWORKOUT","progress" to "▥\nPROGRESS","more" to "☰\nMORE").forEach{(k,v)->NavigationBarItem(selected=page==k,onClick={go(k)},icon={Text(v.substringBefore('\n'),fontSize=20.sp,fontWeight=FontWeight.Black)},label={Text(v.substringAfter('\n'),fontSize=10.sp,fontWeight=FontWeight.Bold)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Ink,selectedTextColor=Ink,indicatorColor=Lime,unselectedIconColor=White,unselectedTextColor=White))}}}

@Composable private fun Setup(done:(Targets)->Unit){var age by remember{mutableStateOf("")};var h by remember{mutableStateOf("")};var w by remember{mutableStateOf("")};var goal by remember{mutableStateOf("Lose")};LazyColumn(Modifier.fillMaxSize().background(Paper).padding(24.dp)){item{Text("RISE",fontSize=48.sp,fontWeight=FontWeight.Black);Text("RESILIENCE • IMPROVEMENT • STRENGTH • ENERGY",fontSize=11.sp,fontWeight=FontWeight.Bold,color=Purple);Spacer(Modifier.height(25.dp));Text("Build your stronger self.",fontSize=28.sp,fontWeight=FontWeight.Black);Text("Your details are saved on this device.",color=Muted);Spacer(Modifier.height(20.dp));Field("Age",age){age=it.filter(Char::isDigit)};Field("Height (cm)",h){h=it.filter(Char::isDigit)};Field("Weight (kg)",w){w=it};Text("Goal",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Lose","Maintain","Gain").forEach{FilterChip(goal==it,{goal=it},label={Text(it)})}};Spacer(Modifier.height(20.dp));BigButton("START RISE",Lime){val kg=w.toDoubleOrNull()?:70.0;val cm=h.toDoubleOrNull()?:170.0;val a=age.toDoubleOrNull()?:25.0;val bmr=10*kg+6.25*cm-5*a+5;val maintenance=bmr*1.5;val cal=when(goal){"Lose"->max(1500.0,maintenance-350).toInt();"Gain"->(maintenance+250).toInt();else->maintenance.toInt()};done(Targets(cal,max(60,(kg*1.8).toInt()),max(25,(cal/1000.0*14).toInt()),max(2000,(kg*35).toInt())));};Spacer(Modifier.height(10.dp));Text("Targets are estimates for planning only.",fontSize=11.sp,color=Muted)}}}

@Composable private fun Home(t:Targets,l:Log,water:(Int)->Unit){LazyColumn(Modifier.fillMaxSize().padding(18.dp)){item{Text("TODAY",color=Lime,modifier=Modifier.background(Ink).padding(horizontal=6.dp,vertical=2.dp),fontWeight=FontWeight.Black);Text("Keep going. 💪",fontSize=34.sp,fontWeight=FontWeight.Black);Text("One good choice at a time.",color=Muted);Spacer(Modifier.height(18.dp));Metric("Calories","🔥",l.calories,t.calories,"kcal",Pink);Metric("Protein","💪",l.protein,t.protein,"g",Lime);Metric("Fiber","🌾",l.fiber,t.fiber,"g",Purple);Metric("Water","💧",l.water,t.water,"ml",Blue);Metric("Steps","👟",l.steps,t.steps,"",Purple);Metric("Sleep","🌙",(l.sleep*60).toInt(),(t.sleep*60).toInt(),"min",Purple);CardBlock(Purple){Text("QUICK WATER",fontWeight=FontWeight.Black);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf(250,500,750,1000).forEach{OutlinedButton({water(it)},Modifier.weight(1f),border=BorderStroke(2.dp,Ink)){Text("${it}ml",fontWeight=FontWeight.Bold)}}}};CardBlock(Pink){Text("ACTIVE CALORIES",fontWeight=FontWeight.Black);Text("${l.burned} kcal",fontSize=28.sp,fontWeight=FontWeight.Black)}}}}

@Composable private fun Metric(name:String,emoji:String,current:Int,target:Int,unit:String,accent:Color){val p=(current.toFloat()/target.coerceAtLeast(1)).coerceIn(0f,1f);CardBlock(accent){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(70.dp).border(3.dp,Ink).background(Paper),contentAlignment=Alignment.Center){Text(emoji,fontSize=30.sp)};Spacer(Modifier.width(14.dp));Column(Modifier.weight(1f)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(name,fontWeight=FontWeight.Black,fontSize=19.sp);Text("${max(0,target-current)} $unit left",color=accent,fontWeight=FontWeight.Black)};LinearProgressIndicator({p},Modifier.fillMaxWidth().height(8.dp),color=accent,trackColor=Color(0xFFE2E2E2));Text("$current / $target $unit",color=Muted,fontSize=12.sp)}}}}}

@Composable private fun Food(l:Log,meals:List<Meal>,add:(Meal)->Unit){var name by remember{mutableStateOf("")};var c by remember{mutableStateOf("")};var p by remember{mutableStateOf("")};var f by remember{mutableStateOf("")};LazyColumn(Modifier.fillMaxSize().padding(18.dp)){item{Header("FOOD",Pink,"Log every meal and add a photo each time.");CardBlock(Purple){Text("📸  CLICK MEAL PHOTO",fontWeight=FontWeight.Black,fontSize=20.sp);Text("Use the camera when you eat. Photo support is wired for the next media step.",color=Muted)};Field("Meal / food",name){name=it};Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){Field("Calories",c){c=it.filter(Char::isDigit)};Field("Protein",p){p=it.filter(Char::isDigit)};Field("Fiber",f){f=it.filter(Char::isDigit)}};BigButton("ADD MEAL",Pink){if(name.isNotBlank()){add(Meal(name,c.toIntOrNull()?:0,p.toIntOrNull()?:0,f.toIntOrNull()?:0));name="";c="";p="";f=""}};Spacer(Modifier.height(14.dp));Text("TODAY'S MEALS",fontWeight=FontWeight.Black,fontSize=20.sp)};items(meals.reversed()){m->CardBlock(Pink){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(m.name,fontWeight=FontWeight.Black);Text("${m.calories} kcal",color=Pink,fontWeight=FontWeight.Black)};Text("${m.protein}g protein • ${m.fiber}g fiber",color=Muted)}}}}

@Composable private fun Workout(done:Set<String>,toggle:(String)->Unit){val plan=mapOf("MON" to listOf("Bench Press","Incline Dumbbell Press","Cable Fly","Triceps Pushdown"),"TUE" to listOf("Lat Pulldown","Seated Row","Dumbbell Curl","Hammer Curl"),"WED" to listOf("Squat","Leg Press","Leg Curl","Calf Raise"),"THU" to listOf("REST / MOBILITY"),"FRI" to listOf("Overhead Press","Lateral Raise","Rear Delt Fly","Plank"),"SAT" to listOf("Full Body / Sport"),"SUN" to listOf("REST"));LazyColumn(Modifier.fillMaxSize().padding(18.dp)){item{Header("WORKOUT",Purple,"Simple plan. Check off what you finish.")};plan.forEach{(day,exs)->item{CardBlock(Purple){Text(day,fontWeight=FontWeight.Black,color=Purple);exs.forEach{ex->val id="$day-$ex";Row(Modifier.fillMaxWidth().clickable{toggle(id)}.padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(id in done,{toggle(id)});Text(ex,fontWeight=if(id in done)FontWeight.Normal else FontWeight.Bold)}}}}}}}}

@Composable private fun Progress(l:Log,media:List<String>,saveWeight:(Double)->Unit){var w by remember{mutableStateOf(if(l.weight==0.0)"" else l.weight.toString())};LazyColumn(Modifier.fillMaxSize().padding(18.dp)){item{Header("PROGRESS",Purple,"Track the changes you can see and measure.");CardBlock(Pink){Text("🔥 STREAK",fontWeight=FontWeight.Black);Text("3 DAYS",fontSize=34.sp,fontWeight=FontWeight.Black);Text("Scheduled rest days don't break your streak.",color=Muted)};CardBlock(Purple){Text("⚖ DAILY WEIGHT",fontWeight=FontWeight.Black);Field("Weight (kg)",w){w=it};BigButton("SAVE WEIGHT",Purple){w.toDoubleOrNull()?.let(saveWeight)}};CardBlock(Lime){Text("🏆 BADGES EARNED",fontWeight=FontWeight.Black);Text("🔥 Consistency starter");Text("💪 First workout");Text("💧 Hydration starter");Text("🥇 First week complete")};CardBlock(Blue){Text("📸 PROFILE • PHOTOS • VIDEOS",fontWeight=FontWeight.Black);Text("Your daily photos, weekly videos and day-by-day reports will live in More → Profile.",color=Muted);Text("${media.size} saved media item(s)",fontWeight=FontWeight.Black)}}}}

@Composable private fun More(l:Log,sports:List<Sport>,media:List<String>,addSport:(Sport)->Unit,addMedia:(String)->Unit,saveSleep:(Float)->Unit){var sport by remember{mutableStateOf("")};var min by remember{mutableStateOf("")};var sleep by remember{mutableStateOf(if(l.sleep==0f)"" else l.sleep.toString())};var showCalc by remember{mutableStateOf(false)};val pickImage=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u->u?.let{addMedia(it.toString())}};val pickVideo=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u->u?.let{addMedia(it.toString())}};LazyColumn(Modifier.fillMaxSize().padding(18.dp)){item{Header("MORE",Lime,"Your profile, reports and tools.");CardBlock(Purple){Text("👤 PROFILE",fontWeight=FontWeight.Black,fontSize=21.sp);Text("Photos • videos • day reports • badges",color=Muted);Spacer(Modifier.height(8.dp));BigButton("ADD PROFILE PHOTO",Purple){pickImage.launch("image/*")};Spacer(Modifier.height(6.dp));BigButton("ADD PROGRESS VIDEO",Purple){pickVideo.launch("video/*")};Text("${media.size} saved media item(s)",fontWeight=FontWeight.Black)};CardBlock(Blue){Text("🌙 SLEEP",fontWeight=FontWeight.Black);Field("Hours slept",sleep){sleep=it};BigButton("SAVE SLEEP",Blue){sleep.toFloatOrNull()?.let(saveSleep)};Text("Saved locally with your daily data.",color=Muted)};CardBlock(Lime){Text("🧮 NORMAL CALCULATOR",fontWeight=FontWeight.Black);BigButton(if(showCalc)"HIDE CALCULATOR" else "OPEN CALCULATOR",Lime){showCalc=!showCalc};if(showCalc)SimpleCalculator()};CardBlock(Pink){Text("🏏 SPORTS",fontWeight=FontWeight.Black);Field("Sport",sport){sport=it};Field("Minutes",min){min=it.filter(Char::isDigit)};BigButton("ADD SESSION",Pink){val m=min.toIntOrNull()?:0;if(sport.isNotBlank()&&m>0){addSport(Sport(sport,m,m*7));sport="";min=""}};sports.takeLast(5).reversed().forEach{Text("${it.name} • ${it.minutes} min • ${it.calories} kcal",color=Muted)}};CardBlock(Purple){Text("📁 DAY REPORTS",fontWeight=FontWeight.Black);Text("Today • nutrition • water • workout • sleep • weight",color=Muted);Text("Past days will become a full calendar/report view in the next build.",color=Muted)}}}}

@Composable private fun SimpleCalculator(){var a by remember{mutableStateOf("")};var op by remember{mutableStateOf("")};var b by remember{mutableStateOf("")};var result by remember{mutableStateOf("0")};Column{Text(result,Modifier.fillMaxWidth().border(2.dp,Ink).padding(18.dp),fontSize=30.sp,fontWeight=FontWeight.Black);Spacer(Modifier.height(8.dp));LazyVerticalGrid(GridCells.Fixed(4),Modifier.height(280.dp)){listOf("AC","+/-","%","⌫","7","8","9","×","4","5","6","−","1","2","3","+","0",".","=","÷").forEach{key->item{Button({when(key){"AC"->{a="";b="";op="";result="0"};"= "->{};"="->{val x=a.toDoubleOrNull();val y=b.toDoubleOrNull();result=if(x!=null&&y!=null)when(op){"+"->(x+y).toString();"−"->(x-y).toString();"×"->(x*y).toString();"÷"->if(y==0.0)"Error" else(x/y).toString();else->b}else"0"};"+","−","×","÷"->{if(a.isNotBlank()){op=key}else{a=result};};else->{if(key=="%"){if(op.isBlank())a=(a.toDoubleOrNull()?.div(100.0)?.toString()?:a) else b=(b.toDoubleOrNull()?.div(100.0)?.toString()?:b)}else if(key=="+/-"){if(op.isBlank())a=(a.toDoubleOrNull()?.times(-1)?.toString()?:a) else b=(b.toDoubleOrNull()?.times(-1)?.toString()?:b)}else if(key=="⌫"){if(op.isBlank())a=a.dropLast(1) else b=b.dropLast(1)}else if(op.isBlank())a+=key else b+=key}},Modifier.padding(2.dp)){Text(key,fontWeight=FontWeight.Black)}}}}}}

@Composable private fun Header(title:String,accent:Color,sub:String){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text(title,fontSize=31.sp,fontWeight=FontWeight.Black);Text(sub,color=Muted)}}Box(Modifier.size(42.dp).background(accent).border(2.dp,Ink),contentAlignment=Alignment.Center){Text("+",fontSize=26.sp,fontWeight=FontWeight.Black)}}}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},modifier=Modifier.fillMaxWidth().padding(bottom=7.dp),singleLine=true,colors=OutlinedTextFieldDefaults.colors(focusedBorderColor=Ink,unfocusedBorderColor=Color(0xFF777777),focusedLabelColor=Ink,unfocusedLabelColor=Muted))}
@Composable private fun CardBlock(accent:Color=Ink,content:@Composable ColumnScope.()->Unit){Card(colors=CardDefaults.cardColors(White),shape=RoundedCornerShape(4.dp),border=BorderStroke(2.dp,Ink),modifier=Modifier.fillMaxWidth().padding(bottom=10.dp)){Column(Modifier.padding(15.dp).background(White),content=content)}}
@Composable private fun BigButton(text:String,accent:Color,onClick:()->Unit){Button(onClick,colors=ButtonDefaults.buttonColors(containerColor=accent,contentColor=Ink),shape=RoundedCornerShape(2.dp),border=BorderStroke(2.dp,Ink),modifier=Modifier.fillMaxWidth().height(52.dp)){Text(text,fontWeight=FontWeight.Black)}}
