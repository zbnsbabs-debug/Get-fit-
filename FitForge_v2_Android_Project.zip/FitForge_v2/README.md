# FitForge v2

Android fitness app starter built with Kotlin + Jetpack Compose.

Included in this version:
- First-launch onboarding
- Goal selection: lose / maintain / gain
- Estimated calorie target
- Protein, fiber and water targets
- Meal logging with calories/protein/fiber
- Quick water buttons
- Daily dashboard and progress bars
- Weekly 5-day workout plan
- Exercise checklist with completion state
- Weight logging
- Progress/streak/badges
- Sports logging
- Fitness calculators
- Local in-memory state for the current session

Next production steps:
- Room database persistence
- Health Connect permissions/integration
- Camera/gallery progress photos and weekly videos
- Notifications/reminders
- Food database/barcode scanning
- Proper calorie/protein calculation using validated formulas and user settings
