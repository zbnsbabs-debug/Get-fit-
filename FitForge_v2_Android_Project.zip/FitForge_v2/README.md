# RISE Fitness App

RISE — Resilience • Improvement • Strength • Energy.

This version uses a neo-brutalist visual system with high-contrast black/white UI and restrained lime, purple and pink accents. User profile, targets, daily nutrition, water, workouts, weight, sleep, meals and sports are persisted locally with SharedPreferences.

Next production step: Room database + Health Connect + robust media storage.
